﻿param([switch]$SelfTest, [string]$RenderPath='', [string]$ChoiceId='')
$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
Import-Module (Join-Path $PSScriptRoot 'InstallCore.psm1') -Force

function Load-PreviewBitmap([string]$Path) {
    $bitmap=[Windows.Media.Imaging.BitmapImage]::new()
    $bitmap.BeginInit(); $bitmap.CacheOption='OnLoad'
    $bitmap.UriSource=[Uri]::new([IO.Path]::GetFullPath($Path))
    $bitmap.EndInit(); $bitmap.Freeze()
    return $bitmap
}

function Update-Preview([string]$Id) {
    $script:selected=@($script:choices | Where-Object { $_.id -eq $Id })[0]
    $script:previewTitle.Text=$script:selected.name
    $script:preview.Source=$script:previewCache[$Id][0]
    $script:previewIndex=0
    $script:previewClock.Restart()
    $script:status.Text="安装后，在 Codex 的宠物设置里刷新并选择「$($script:selected.displayName)」。"
}

try {
    $script:manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'choices.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $script:choices=$script:manifest.choices
    if (-not $ChoiceId) { $ChoiceId=$script:manifest.default }
    $script:previewCache=@{}
    foreach ($choice in $script:choices) {
        $script:previewCache[$choice.id]=@($choice.frames | ForEach-Object { Load-PreviewBitmap (Join-Path $PSScriptRoot ($choice.preview+'/'+$_.asset)) })
    }
    [xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
 Title="奶蛋 · 待机动作安装器" Width="760" Height="720" ResizeMode="NoResize" WindowStartupLocation="CenterScreen"
 Background="#FAF7ED" Foreground="#34472B" FontFamily="Microsoft YaHei" FontSize="14">
 <Window.Resources><Style TargetType="Button"><Setter Property="Padding" Value="16,9"/><Setter Property="Margin" Value="5,0"/></Style></Window.Resources>
 <Grid Margin="26" Background="#FAF7ED">
  <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="270"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
  <TextBlock x:Name="Heading" FontSize="25" FontWeight="SemiBold"/>
  <TextBlock Grid.Row="1" Margin="0,10,0,16" TextWrapping="Wrap" Foreground="#637356" x:Name="Subtitle"/>
  <Grid Grid.Row="2"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions>
   <StackPanel x:Name="ChoicesPanel" VerticalAlignment="Center"/>
   <Border Grid.Column="1" Background="#F0EEDF" CornerRadius="16" Padding="10">
    <StackPanel VerticalAlignment="Center"><TextBlock x:Name="PreviewTitle" TextAlignment="Center" FontWeight="SemiBold" TextWrapping="Wrap"/>
     <Image x:Name="PreviewImage" Width="192" Height="208" Stretch="Uniform"/>
     <TextBlock Text="原生待机节奏预览" FontSize="11" Foreground="#6C785C" HorizontalAlignment="Center"/>
    </StackPanel>
   </Border>
  </Grid>
  <Border Grid.Row="3" Background="#ECEFD9" CornerRadius="8" Padding="12" Margin="0,14,0,14">
   <TextBlock TextWrapping="Wrap" FontSize="12" x:Name="Notice"/>
  </Border>
  <StackPanel Grid.Row="4"><TextBlock Text="Codex 宠物目录" Margin="0,0,0,6"/>
   <DockPanel><Button x:Name="BrowseButton" Content="浏览…" DockPanel.Dock="Right"/><TextBox x:Name="TargetPath" Padding="8" VerticalContentAlignment="Center"/></DockPanel>
  </StackPanel>
  <TextBlock Grid.Row="5" x:Name="StatusText" TextWrapping="Wrap" Margin="0,14,0,10" FontSize="12" Foreground="#637356"/>
  <DockPanel Grid.Row="6"><Button x:Name="InstallButton" DockPanel.Dock="Right" Content="安装所选待机" Background="#DCE6C6" FontWeight="SemiBold"/>
   <TextBlock VerticalAlignment="Center" FontSize="12" Text="四种动作分别保存，可在 Codex 中切换。"/>
  </DockPanel>
 </Grid>
</Window>
'@
    $reader=[Xml.XmlNodeReader]::new($xaml)
    $script:window=[Windows.Markup.XamlReader]::Load($reader)
    $script:window.Title=$script:manifest.windowTitle
    $script:window.FindName('Heading').Text=$script:manifest.windowTitle
    $script:window.FindName('Subtitle').Text=$script:manifest.subtitle
    $script:window.FindName('Notice').Text=$script:manifest.notice
    $script:preview=$script:window.FindName('PreviewImage')
    $script:previewTitle=$script:window.FindName('PreviewTitle')
    $script:status=$script:window.FindName('StatusText')
    $script:targetPath=$script:window.FindName('TargetPath')
    $script:targetPath.Text=Get-NaiEggTargetRoot
    $panel=$script:window.FindName('ChoicesPanel')
    $script:previewClock=[Diagnostics.Stopwatch]::StartNew()
    foreach ($choice in $script:choices) {
        $radio=[Windows.Controls.RadioButton]::new()
        $radio.Tag=$choice.id; $radio.GroupName='IdleChoice'; $radio.Margin='0,8,12,8'
        $stack=[Windows.Controls.StackPanel]::new()
        $title=[Windows.Controls.TextBlock]::new(); $title.Text=$choice.name; $title.FontWeight='SemiBold'; $title.FontSize=15
        $description=[Windows.Controls.TextBlock]::new(); $description.Text=$choice.description; $description.FontSize=11
        $description.Foreground=[Windows.Media.BrushConverter]::new().ConvertFromString('#637356'); $description.Margin='0,4,0,0'; $description.TextWrapping='Wrap'; $description.MaxWidth=375
        [void]$stack.Children.Add($title); [void]$stack.Children.Add($description); $radio.Content=$stack
        $radio.Add_Checked({param($sender,$eventArgs) Update-Preview ([string]$sender.Tag) })
        [void]$panel.Children.Add($radio)
        if ($choice.id -eq $ChoiceId) { $radio.IsChecked=$true }
    }
    if ($null -eq $script:selected) { throw '未知待机选项。' }
    $script:window.FindName('BrowseButton').Add_Click({
        Add-Type -AssemblyName System.Windows.Forms
        $dialog=[Windows.Forms.FolderBrowserDialog]::new()
        $dialog.Description='选择 Codex 的 pets 文件夹'
        $dialog.SelectedPath=$script:targetPath.Text
        if ($dialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) { $script:targetPath.Text=$dialog.SelectedPath }
        $dialog.Dispose()
    })
    $script:window.FindName('InstallButton').Add_Click({param($sender,$eventArgs)
        $sender.IsEnabled=$false
        try {
            $result=Install-NaiEggVariant -BundleRoot $PSScriptRoot -ChoiceId $script:selected.id -TargetRoot $script:targetPath.Text.Trim()
            $script:status.Text="已安装「$($result.Choice)」。请在 Codex 宠物设置中刷新并选择「$($script:selected.displayName)」。"
            $message="已安装：$($result.Choice)`n`n请回到 Codex → 设置 → 宠物 → 刷新，再选择「$($script:selected.displayName)」。"
            if ($result.BackupPath) { $message+="`n`n上一版本已备份到：`n$($result.BackupPath)" }
            [void][Windows.MessageBox]::Show($script:window,$message,'奶蛋安装完成','OK','Information')
        } catch {
            $script:status.Text='安装未完成，已有版本已保留或恢复。'
            [void][Windows.MessageBox]::Show($script:window,$_.Exception.Message,'安装未完成','OK','Error')
        } finally { $sender.IsEnabled=$true }
    })
    if ($SelfTest) {
        foreach ($radio in $panel.Children) {
            $radio.IsChecked=$true
            if ($script:selected.id -ne $radio.Tag) { throw '待机选项未正确更新预览。' }
            if (-not $script:status.Text.Contains($script:selected.displayName)) { throw '提示的宠物名称不正确。' }
        }
        foreach ($radio in $panel.Children) { if ($radio.Tag -eq $ChoiceId) { $radio.IsChecked=$true } }
        if ($RenderPath) {
            $content=$script:window.Content
            $content.Measure([Windows.Size]::new(760,680))
            $content.Arrange([Windows.Rect]::new(0,0,760,680))
            $content.UpdateLayout()
            $render=[Windows.Media.Imaging.RenderTargetBitmap]::new(760,680,96,96,[Windows.Media.PixelFormats]::Pbgra32)
            $render.Render($content)
            $encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new(); $encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($render))
            $stream=[IO.File]::Create($RenderPath)
            try { $encoder.Save($stream) } finally { $stream.Dispose() }
        }
        [pscustomobject]@{ ok=$true; choices=$script:choices.Count; selected=$script:selected.id; assetsDecoded=($script:choices | ForEach-Object { $_.frames.Count } | Measure-Object -Sum).Sum; selectionEventsTested=$true; installed=$false } | ConvertTo-Json -Compress
        return
    }
    $timer=[Windows.Threading.DispatcherTimer]::new()
    $timer.Interval=[TimeSpan]::FromMilliseconds(40)
    $timer.Add_Tick({
        $durations=@($script:selected.frames | ForEach-Object { [int]$_.durationMs })
        $total=($durations | Measure-Object -Sum).Sum
        $position=$script:previewClock.ElapsedMilliseconds % $total
        $index=0
        while ($index -lt ($durations.Count-1) -and $position -ge $durations[$index]) { $position-=$durations[$index]; $index++ }
        if ($index -ne $script:previewIndex) { $script:preview.Source=$script:previewCache[$script:selected.id][$index]; $script:previewIndex=$index }
    })
    $timer.Start()
    try { [void]$script:window.ShowDialog() }
    finally { $timer.Stop(); $script:previewClock.Stop() }
} catch {
    if ($SelfTest) { throw }
    [void][Windows.MessageBox]::Show("无法打开安装器：`n$($_.Exception.Message)",'奶蛋')
    exit 1
}

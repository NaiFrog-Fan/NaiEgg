﻿Set-StrictMode -Version Latest

function Get-NaiEggTargetRoot {
    if (-not [string]::IsNullOrWhiteSpace($env:CODEX_HOME)) {
        return Join-Path $env:CODEX_HOME 'pets'
    }
    return Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex\pets'
}

function Install-NaiEggVariant {
    param([Parameter(Mandatory=$true)][string]$BundleRoot,
          [Parameter(Mandatory=$true)][string]$ChoiceId,
          [Parameter(Mandatory=$true)][string]$TargetRoot)
    $ErrorActionPreference='Stop'
    $manifest=Get-Content -LiteralPath (Join-Path $BundleRoot 'choices.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $choice=@($manifest.choices | Where-Object { $_.id -eq $ChoiceId })
    if ($choice.Count -ne 1) { throw '请选择有效的待机动作。' }
    $choice=$choice[0]
    $petId=[string]$choice.petId
    if ($petId -notmatch '^[a-z0-9][a-z0-9-]{0,63}$') { throw '宠物标识无效。' }
    $bundle=[IO.Path]::GetFullPath($BundleRoot).TrimEnd('\')
    $source=[IO.Path]::GetFullPath((Join-Path $bundle $choice.folder))
    if (-not $source.StartsWith($bundle+'\',[StringComparison]::OrdinalIgnoreCase)) { throw '安装包路径异常。' }
    foreach ($file in @('pet.json','spritesheet.webp')) {
        $path=Join-Path $source $file
        $hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $choice.hashes.$file) { throw "安装包校验失败：$file。请重新解压完整安装包。" }
    }
    $config=Get-Content -LiteralPath (Join-Path $source 'pet.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($config.id -ne $petId -or $config.spriteVersionNumber -ne 2 -or $config.spritesheetPath -ne 'spritesheet.webp') { throw '宠物配置不符合预期。' }
    if (-not [IO.Path]::IsPathRooted($TargetRoot)) { throw '请选择完整的宠物目录路径。' }
    $root=[IO.Path]::GetFullPath($TargetRoot).TrimEnd('\')
    $target=Join-Path $root $petId
    if (Test-Path -LiteralPath $target) {
        if ((Get-Item -LiteralPath $target).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw '奶蛋目标目录为链接，请改用普通目录。' }
    }
    New-Item -ItemType Directory -Path $root -Force | Out-Null
    $backup=$null
    if (Test-Path -LiteralPath $target) {
        $backup=Join-Path (Split-Path $root -Parent) ('pet-backups\'+$petId+'\'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6))
        New-Item -ItemType Directory -Path $backup -Force | Out-Null
        foreach ($file in @('pet.json','spritesheet.webp')) {
            $old=Join-Path $target $file
            if (Test-Path -LiteralPath $old) { Copy-Item -LiteralPath $old -Destination (Join-Path $backup $file) }
        }
    }
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    $suffix='.pending-'+[Guid]::NewGuid().ToString('N')
    $replaced=[System.Collections.Generic.List[string]]::new()
    try {
        foreach ($file in @('spritesheet.webp','pet.json')) {
            Copy-Item -LiteralPath (Join-Path $source $file) -Destination (Join-Path $target ($file+$suffix))
        }
        foreach ($file in @('spritesheet.webp','pet.json')) {
            Move-Item -LiteralPath (Join-Path $target ($file+$suffix)) -Destination (Join-Path $target $file) -Force
            $replaced.Add($file)
            if ((Get-FileHash -LiteralPath (Join-Path $target $file) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $choice.hashes.$file) { throw '安装后的文件校验失败。' }
        }
    } catch {
        foreach ($file in $replaced) {
            $old=if ($null -ne $backup) { Join-Path $backup $file } else { $null }
            if ($null -ne $old -and (Test-Path -LiteralPath $old)) {
                Copy-Item -LiteralPath $old -Destination (Join-Path $target $file) -Force
            } else { Remove-Item -LiteralPath (Join-Path $target $file) -Force -ErrorAction SilentlyContinue }
        }
        throw
    } finally {
        foreach ($file in @('spritesheet.webp','pet.json')) {
            $pending=Join-Path $target ($file+$suffix)
            if (Test-Path -LiteralPath $pending) { Remove-Item -LiteralPath $pending -Force }
        }
    }
    return [pscustomobject]@{ Choice=$choice.name; DisplayName=$choice.displayName; PetId=$petId; InstalledPath=$target; BackupPath=$backup; Verified=$true }
}

Export-ModuleMember -Function Get-NaiEggTargetRoot,Install-NaiEggVariant
